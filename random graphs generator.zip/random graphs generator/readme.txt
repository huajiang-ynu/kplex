For generating graphs with vertices N and density D,please use command:
./run.sh N D

For example 
./run.sh 500 0.5
