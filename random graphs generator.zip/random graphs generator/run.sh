#!/bin/sh
graph_choice_number=0
max_number_of_edges=10000000
sparse=1

mkdir $1_$2

for n in {1..20}
do
echo $graph_choice_number >> $n.sed
echo $RANDOM >> $n.sed
echo $1 >> $n.sed
echo $max_number_of_edges >> $n.sed
echo $2 >> $n.sed
echo $sparse >> $n.sed
./ggen $n.sed ./$1_$2/r$1_$2_$n.clq
done

for n in {1..20}
do
rm $n.sed
done

